<?php
// Database connection (replace with your connection details)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle booking form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_room'])) {
    $room_number = $_POST['room_number'];
    $patient_name = $_POST['patient_name'];
    $patient_age = $_POST['patient_age'];
    $patient_condition = $_POST['patient_condition'];

    // Insert patient details into room_bookings table
    $stmt = $conn->prepare("INSERT INTO room_bookings (room_number, patient_name, patient_age, patient_condition) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $room_number, $patient_name, $patient_age, $patient_condition);
    $stmt->execute();

    // Update room status to 'booked'
    $updateStmt = $conn->prepare("UPDATE rooms SET status = 'booked' WHERE room_number = ?");
    $updateStmt->bind_param("s", $room_number);
    $updateStmt->execute();

    header("Location: " . $_SERVER['PHP_SELF']); // Refresh the page
    exit();
}

// Query to get room status
$sql = "SELECT room_number, status FROM rooms";
$result = $conn->query($sql);

// Query to get in-patient details
$patientSql = "SELECT * FROM room_bookings";
$patientResult = $conn->query($patientSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Availability - HMS Health Care</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Your existing CSS styles */
        body {
            background-color: #e9f5f9;
            font-family: 'Helvetica', sans-serif;
        }
        .container {
            margin-top: 40px;
        }
        h2, h3 {
            color: #007bff;
            font-weight: 700;
        }
        .room {
            width: 140px;
            height: 140px;
            margin: 15px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 600;
            color: white;
            border-radius: 12px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .room:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
        }
        .available {
            background-color: #28a745;
        }
        .booked {
            background-color: #dc3545;
            pointer-events: none;
        }
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1000;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            width: 90%;
            max-width: 500px;
        }
        .modal-header {
            border-bottom: 1px solid #e9ecef;
            margin-bottom: 20px;
        }
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 999;
        }
        .overlay.active, .modal.active {
            display: block;
        }
        .patient-table {
            margin-top: 40px;
            border: 1px solid #ddd;
        }
        .patient-table th, .patient-table td {
            text-align: center;
            padding: 10px;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-5">Room Availability</h2>
        <div class="d-flex flex-wrap justify-content-center">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $roomClass = $row['status'] === 'booked' ? 'booked' : 'available';
                    echo '<div class="room ' . $roomClass . '" data-room="' . $row['room_number'] . '">Room ' . $row['room_number'] . '</div>';
                }
            } else {
                echo "<p class='text-center'>No rooms found.</p>";
            }
            ?>
        </div>

        <!-- Booking Modal -->
        <div class="overlay"></div>
        <div class="modal">
            <div class="modal-header">
                <h4>Book Room</h4>
            </div>
            <form method="post">
                <input type="hidden" name="room_number" id="room_number">
                <div class="form-group">
                    <label for="patient_name">Patient Name</label>
                    <input type="text" class="form-control" id="patient_name" name="patient_name" required>
                </div>
                <div class="form-group">
                    <label for="patient_age">Patient Age</label>
                    <input type="number" class="form-control" id="patient_age" name="patient_age" required>
                </div>
                <div class="form-group">
                    <label for="patient_condition">Patient Condition</label>
                    <textarea class="form-control" id="patient_condition" name="patient_condition" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary" name="book_room">Book Room</button>
            </form>
        </div>

        <!-- In-Patient Details Table -->
        <h3 class="text-center mt-5">In-Patient Details</h3>
        <table class="patient-table table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Patient ID</th>
                    <th>Room Number</th>
                    <th>Patient Name</th>
                    <th>Age</th>
                    <th>Condition</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php
                if ($patientResult->num_rows > 0) {
                    while ($row = $patientResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>"; // Assuming 'id' is the primary key
                        echo "<td>" . $row['room_number'] . "</td>";
                        echo "<td>" . $row['patient_name'] . "</td>";
                        echo "<td>" . $row['patient_age'] . "</td>";
                        echo "<td>" . $row['patient_condition'] . "</td>";
                       
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No in-patient details found.</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.room.available').click(function() {
                var roomNumber = $(this).data('room');
                $('#room_number').val(roomNumber);
                $('.modal, .overlay').addClass('active');
            });

            $('.overlay').click(function() {
                $('.modal, .overlay').removeClass('active');
            });
        });
    </script>
    <!-- Shift Scheduling Section -->
<h3 class="text-center mt-5">Shift Scheduling</h3>
<table class="shift-table table table-bordered">
    <thead class="thead-light">
        <tr>
            <th>Staff ID</th>
            <th>Staff Name</th>
            <th>Shift Date</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Assigned Room</th>
        </tr>
    </thead>
    <tbody>
        <!-- Sample data (you can replace it with dynamic content from your database) -->
        <tr>
            <td>101</td>
            <td>Dr. Smith</td>
            <td>2024-11-03</td>
            <td>08:00 AM</td>
            <td>04:00 PM</td>
            <td>Room 12</td>
        </tr>
        <tr>
            <td>102</td>
            <td>Nurse Jane</td>
            <td>2024-11-03</td>
            <td>10:00 AM</td>
            <td>06:00 PM</td>
            <td>Room 8</td>
        </tr>
        <tr>
            <td>103</td>
            <td>Dr. Brown</td>
            <td>2024-11-03</td>
            <td>02:00 PM</td>
            <td>10:00 PM</td>
            <td>Room 5</td>
        </tr>
        <tr>
            <td>105</td>
            <td>Nurse Shalu</td>
            <td>2024-11-03</td>
            <td>11:00 AM</td>
            <td>04:00 PM</td>
            <td>Room 105</td>
        </tr>
        <tr>
            <td>112</td>
            <td>Nurse shaki</td>
            <td>2024-11-03</td>
            <td>8:00 AM</td>
            <td>03:00 PM</td>
            <td>Room 12</td>
        </tr>
    </tbody>
</table>

<style>
    .shift-table {
        margin-top: 20px;
        border: 1px solid #ddd;
    }
    .shift-table th, .shift-table td {
        text-align: center;
        padding: 10px;
    }
</style>

</body>
</html>
