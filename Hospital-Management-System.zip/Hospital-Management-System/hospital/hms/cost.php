<?php
include('include/config.php'); // Including configuration for database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Doctor Payment Report</title>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <style>
        /* Styling the container */
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f7fa;
        }

        .container {
            max-width: 800px;
            margin-top: 40px;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
        }

        h2 {
            color: #4a90e2;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }

        /* Styling form elements */
        .form-group label {
            color: #4a4a4a;
            font-weight: 500;
        }

        .form-control {
            border: 1px solid #ced4da;
            border-radius: 4px;
        }

        .btn-primary {
            background-color: #4a90e2;
            border-color: #4a90e2;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #357abd;
            border-color: #357abd;
        }

        /* Table styling */
        #report-results table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        thead {
            background-color: #4a90e2;
            color: #ffffff;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #e0e0e0;
        }

        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tbody tr:hover {
            background-color: #f1f8ff;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Doctor Payment History</h2>
    <form id="searchForm">
        <div class="form-group">
            <label for="doctor">Doctor Name:</label>
            <input type="text" name="doctor" id="doctor" class="form-control" placeholder="Enter Doctor Name">
        </div>
        <div class="form-group">
            <label for="dateFrom">From Date (YYYY-MM-DD):</label>
            <input type="date" name="dateFrom" id="dateFrom" class="form-control">
        </div>
        <div class="form-group">
            <label for="dateTo">To Date (YYYY-MM-DD):</label>
            <input type="date" name="dateTo" id="dateTo" class="form-control">
        </div>
        <button type="button" onclick="filterResults()" class="btn btn-primary btn-block mt-3">Search</button>
    </form>

    <!-- Display search results -->
    <div id="report-results" class="mt-4">
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Doctor Name</th>
                    <th>Appointment Date</th>
                    <th>Fees Paid</th>
                </tr>
            </thead>
            <tbody id="reportTableBody">
                <tr>
                    <td>Dr. Anuj Kumar</td>
                    <td>2024-05-30</td>
                    <td>LKR 2000</td>
                </tr>
                <tr>
                    <td>Dr. Kevin Nugara</td>
                    <td>2024-07-23</td>
                    <td>LKR 30000</td>
                </tr>
                <tr>
                    <td>Dr. Anuj Kumar</td>
                    <td>2024-10-01</td>
                    <td>LKR 2000</td>
                </tr>
                <tr>
                    <td>Dr. Romali</td>
                    <td>2024-10-24</td>
                    <td>LKR 2500</td>
                </tr>
                <tr>
                    <td>Dr. Anuj Kumar</td>
                    <td>2024-11-03</td>
                    <td>LKR 2000</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>

<script>
// JavaScript function to filter results based on user input
function filterResults() {
    const doctorInput = document.getElementById('doctor').value.toLowerCase();
    const dateFromInput = document.getElementById('dateFrom').value;
    const dateToInput = document.getElementById('dateTo').value;
    const tableBody = document.getElementById('reportTableBody');
    const rows = tableBody.getElementsByTagName('tr');
    
    // Loop through each row to filter data
    for (let i = 0; i < rows.length; i++) {
        const doctorName = rows[i].cells[0].innerText.toLowerCase();
        const appointmentDate = rows[i].cells[1].innerText;

        const matchDoctor = !doctorInput || doctorName.includes(doctorInput);
        const matchDate = (!dateFromInput || appointmentDate >= dateFromInput) && (!dateToInput || appointmentDate <= dateToInput);
        
        // Show or hide row based on search criteria
        if (matchDoctor && matchDate) {
            rows[i].style.display = '';
        } else {
            rows[i].style.display = 'none';
        }
    }
}
</script>

</body>
</html>
