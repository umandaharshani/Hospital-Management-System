<?php
// PHP configuration for saving the file as .php
$reportTitle = "Patient Progress and Financial Report";
$doctorName = "Dr. John Doe";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $reportTitle; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
            color: #333;
        }
        h1, h2 {
            text-align: center;
            color: #2c3e50;
        }
        .charts-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .chart {
            width: 30%;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
        }
        .report-details {
            margin-top: 30px;
            padding: 15px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <h1><?php echo $reportTitle; ?></h1>
    <h2>Doctor: <?php echo $doctorName; ?></h2>

    <div class="charts-container">
        <!-- Pie Chart -->
        <div class="chart">
            <canvas id="patientDistributionChart"></canvas>
        </div>
        <!-- Bar Chart -->
        <div class="chart">
            <canvas id="monthlyPatientsChart"></canvas>
        </div>
        <!-- Doughnut Chart -->
        <div class="chart">
            <canvas id="incomeDistributionChart"></canvas>
        </div>
    </div>

    <div class="report-details">
        <h2>Report Details</h2>
        <p><strong>Total Patients:</strong> 20</p>
        <p><strong>Patients by Type:</strong> 60% Outpatients, 40% Inpatients</p>
        <p><strong>Monthly Patient Growth:</strong> Steady increase in patient volume over the past six months.</p>
        <p><strong>Total Income from Patients:</strong> 120,000</p>
        <p><strong>Income Distribution:</strong> Most income generated from surgical procedures and consultations.</p>
    </div>

    <script>
        // Pie Chart: Patient Distribution
        new Chart(document.getElementById('patientDistributionChart'), {
            type: 'pie',
            data: {
                labels: ['Outpatients', 'Inpatients'],
                datasets: [{
                    data: [60, 40],
                    backgroundColor: ['#3498db', '#e74c3c']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Bar Chart: Monthly Patients
        new Chart(document.getElementById('monthlyPatientsChart'), {
            type: 'bar',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June'],
                datasets: [{
                    label: 'Number of Patients',
                    data: [10, 20, 30, 32, 28, 20],
                    backgroundColor: '#2ecc71'
                }]
            },
            options: {
                scales: {
                    y: { beginAtZero: true }
                },
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Doughnut Chart: Income Distribution
        new Chart(document.getElementById('incomeDistributionChart'), {
            type: 'doughnut',
            data: {
                labels: ['Surgery', 'Consultation', 'Pharmacy'],
                datasets: [{
                    data: [50, 30, 20],
                    backgroundColor: ['#9b59b6', '#f1c40f', '#34495e']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    </script>
</body>
</html>
