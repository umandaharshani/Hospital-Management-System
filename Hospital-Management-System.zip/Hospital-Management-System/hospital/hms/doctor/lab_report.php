<?php
// Database connection (update with your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle search by invoice number
$searchInvoiceNumber = "";
$reportFound = false;
$filePath = "";

if (isset($_POST['search_report'])) {
    $searchInvoiceNumber = $_POST['invoice_number'];

    // Search query
    $stmt = $conn->prepare("SELECT * FROM lab_reports WHERE invoice_number = ?");
    $stmt->bind_param("s", $searchInvoiceNumber);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $reportFound = true;
        $report = $result->fetch_assoc();
        $filePath = $report['file_path'];
    } else {
        $reportFound = false;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Lab Report Search - HMS Health Care</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Search Your Lab Report</h2>
        <form method="post" class="mb-4">
            <div class="form-group">
                <label for="invoice_number">Invoice Number</label>
                <input type="text" class="form-control" id="invoice_number" name="invoice_number" required>
            </div>
            <button type="submit" class="btn btn-primary" name="search_report">Search Report</button>
        </form>

        <?php if (isset($_POST['search_report'])): ?>
            <?php if ($reportFound): ?>
                <div class="alert alert-success">
                    <h4 class="alert-heading">Report Found!</h4>
                    <p><strong>Patient Name:</strong> <?php echo $report['patient_name']; ?></p>
                    <p><strong>Report Date:</strong> <?php echo $report['report_date']; ?></p>
                    <p><strong>Invoice Number:</strong> <?php echo $report['invoice_number']; ?></p>
                    <a href="<?php echo $filePath; ?>" class="btn btn-success" download>Download Report</a>
                    <a href="<?php echo $filePath; ?>" class="btn btn-info" target="_blank">View Report</a>
                </div>
            <?php else: ?>
                <div class="alert alert-danger">
                    No report found for the provided invoice number.
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
