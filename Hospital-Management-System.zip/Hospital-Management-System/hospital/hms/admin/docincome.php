<?php
// This PHP section is just for saving it as a .php file
// No dynamic content is included; only HTML is present
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Income BY Doctors</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            margin: 0;
        }
        h1 {
            font-size: 32px;
            color: #007bff;
            margin-bottom: 20px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 900px;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
            text-transform: uppercase;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e1f5fe;
        }
        .chart-container {
            display: flex;
            justify-content: space-around;
            gap: 20px;
            width: 100%;
            max-width: 900px;
            margin-top: 40px;
        }
        canvas {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            width: 45%; /* Adjusts the size to fit two charts side by side */
            max-width: 400px;
            max-height: 300px;
        }
    </style>
    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<h1>Hospital Income by Doctors</h1>

<table>
    <thead>
        <tr>
            <th>Department</th>
            <th>Total Income Last Month (LKR)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Emergency</td>
            <td>1,500,000.00</td>
        </tr>
        <tr>
            <td>Surgery</td>
            <td>2,000,000.00</td>
        </tr>
        <tr>
            <td>Pediatrics</td>
            <td>1,200,000.00</td>
        </tr>
        <tr>
            <td>Radiology</td>
            <td>800,000.00</td>
        </tr>
        <tr>
            <td>Oncology</td>
            <td>1,700,000.00</td>
        </tr>
        <tr>
            <td>Total</td>
            <td>7,400,000.00</td>
        </tr>
    </tbody>
</table>

<!-- Chart containers -->
<div class="chart-container">
    <!-- Bar Chart for Income by Doctors -->
    <canvas id="incomeChart"></canvas>
    <!-- Doughnut Chart for Number of Doctors per Department -->
    <canvas id="doctorDeptChart"></canvas>
</div>

<script>
    // Data for Income by Doctors chart
    const doctorLabels = ['Dr. Anuj', 'Dr. Kevin', 'Dr. Snjeewa', 'Dr. Romil', 'Dr. Chandana'];
    const incomeData = [15000, 20000, 12000, 8000, 17000];

    // Bar chart configuration
    const ctxIncome = document.getElementById('incomeChart').getContext('2d');
    const incomeChart = new Chart(ctxIncome, {
        type: 'bar',
        data: {
            labels: doctorLabels,
            datasets: [{
                label: 'Income by Doctors for Last Month (LKR)',
                data: incomeData,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Income (LKR)'
                    }
                }
            }
        }
    });

    // Data for Number of Doctors per Department chart
    const deptLabels = ['Emergency', 'Surgery', 'Pediatrics', 'Radiology', 'Oncology'];
    const doctorCountData = [10, 15, 12, 8, 5];

    // Doughnut chart configuration
    const ctxDept = document.getElementById('doctorDeptChart').getContext('2d');
    const doctorDeptChart = new Chart(ctxDept, {
        type: 'doughnut',
        data: {
            labels: deptLabels,
            datasets: [{
                label: 'Number of Doctors per Department',
                data: doctorCountData,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.raw + ' doctors';
                        }
                    }
                }
            }
        }
    });
</script>

</body>
</html>
