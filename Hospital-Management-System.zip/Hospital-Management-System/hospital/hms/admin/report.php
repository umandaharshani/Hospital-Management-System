<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Statistics and Information Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        color: #333;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px;
        margin: 0;
    }
    h1 {
        font-size: 28px;
        color: #333;
        margin-bottom: 20px;
    }
    .chart-container {
        display: flex;
        gap: 20px;
        flex-wrap: wrap;
        justify-content: center;
        max-width: 1200px;
        margin-top: 20px;
    }
    .chart-box {
        flex: 1 1 200px;
        background-color: #fff;
        padding: 10px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        max-width: 300px;
        min-width: 200px;
        margin: 10px;
        text-align: center;
    }
    table {
        border-collapse: collapse;
        width: 100%;
        max-width: 900px;
        margin-top: 20px;
        background-color: #fff;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    th, td {
        border: 1px solid #ddd;
        padding: 12px;
        text-align: center;
    }
    th {
        background-color: #007bff;
        color: #fff;
        font-weight: bold;
        text-transform: uppercase;
    }
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    tr:hover {
        background-color: #e0f7fa;
    }
    button {
        margin-top: 20px;
        padding: 10px 20px;
        font-size: 16px;
        color: #fff;
        background-color: #007bff;
        border: none;
        cursor: pointer;
        border-radius: 4px;
        transition: background-color 0.3s;
    }
    button:hover {
        background-color: #0056b3;
    }
</style>

</head>
<body>
    <h1>User Statistics and Information Report</h1>

    <!-- Chart Section -->
    <div class="chart-container">
        <div class="chart-box">
            <h3>User Roles</h3>
            <canvas id="userRolesChart"></canvas>
        </div>
        <div class="chart-box">
            <h3>Monthly Registrations</h3>
            <canvas id="userRegistrationsChart"></canvas>
        </div>
        <div class="chart-box">
            <h3>Registrations by Type</h3>
            <canvas id="registrationsByUserTypeChart"></canvas>
        </div>
        <div class="chart-box">
            <h3>Monthly Appointments</h3>
            <canvas id="appointmentsChart"></canvas>
        </div>
    </div>

    <!-- User Information Table -->
    <table id="userTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Address</th>
                <th>City</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Registered</th>
                <th>Last Login</th>
            </tr>
        </thead>
        <tbody>
            <?php
                // Sample data array (replace with database retrieval in actual implementation)
                $users = [
                    ['id' => 12, 'name' => 'Manuja', 'address' => 'No.2 Haloluwa, Katugastota', 'city' => 'Kandy', 'gender' => 'Male', 'email' => 'manuja@gmail.com', 'registered' => '2024-10-31 10:53:11', 'last_login' => ''],
                    ['id' => 11, 'name' => 'Devan', 'address' => 'No.14 Manikhinna', 'city' => 'Manikhinna', 'gender' => 'Male', 'email' => 'devan@gmail.com', 'registered' => '2024-10-31 10:52:43', 'last_login' => ''],
                    ['id' => 10, 'name' => 'Mallika', 'address' => 'No.19 Kandy', 'city' => 'Kandy', 'gender' => 'Male', 'email' => 'mallika@gmail.com', 'registered' => '2024-10-31 10:50:51', 'last_login' => ''],
                    ['id' => 9, 'name' => 'Thilak', 'address' => 'No.16 Kandy', 'city' => 'Kandy', 'gender' => 'Male', 'email' => 'thilak@gmail.com', 'registered' => '2024-10-31 10:49:32', 'last_login' => ''],
                    ['id' => 8, 'name' => 'Thushan', 'address' => 'No.14 Manikhinna', 'city' => 'Kandy', 'gender' => 'Male', 'email' => 'thushan@gmail.com', 'registered' => '2024-10-31 10:48:47', 'last_login' => ''],
                    ['id' => 7, 'name' => 'Dihara Dayarathna', 'address' => 'No.2 Haloluwa, Katugastota', 'city' => 'Kandy', 'gender' => 'Female', 'email' => 'dihara@gmail.com', 'registered' => '2024-10-27 18:15:01', 'last_login' => ''],
                    ['id' => 6, 'name' => 'Uminda Abeykoon', 'address' => 'No.5 Kandy', 'city' => 'Kandy', 'gender' => 'Female', 'email' => 'umi12@gamil.com', 'registered' => '2024-10-14 12:19:19', 'last_login' => ''],
                    ['id' => 5, 'name' => 'Sky', 'address' => 'No.5 Kandy', 'city' => 'Kandy', 'gender' => 'Female', 'email' => 'sky12@gamil.co', 'registered' => '2024-07-20 12:11:49', 'last_login' => ''],
                    ['id' => 4, 'name' => 'Thushan Rasanjana', 'address' => 'No.3 Manikhinna', 'city' => 'Manikhinna', 'gender' => 'Male', 'email' => 'thushan123@gmail.com', 'registered' => '2024-07-10 20:48:20', 'last_login' => '2024-07-10 20:49:23'],
                    ['id' => 3, 'name' => 'Uminda', 'address' => 'No.3 Kahalla, Katugastota', 'city' => 'Manikhinna', 'gender' => 'Female', 'email' => 'umiharsh123@gmail.com', 'registered' => '2024-07-10 20:31:41', 'last_login' => '2024-07-10 20:34:38'],
                    ['id' => 2, 'name' => 'Amit Kumar', 'address' => 'New Delhi, India', 'city' => 'New Delhi', 'gender' => 'Male', 'email' => 'amitk@gmail.com', 'registered' => '2024-04-21 18:45:32', 'last_login' => '2024-05-14 14:58:23'],
                    ['id' => 1, 'name' => 'John Doe', 'address' => 'NO.3 Peradeniya Road, Kandy', 'city' => 'Kandy', 'gender' => 'Male', 'email' => 'johndoe12@test.com', 'registered' => '2024-04-20 17:43:56', 'last_login' => '2024-10-14 15:02:24'],
                ];
                
                // Loop through users and output table rows
                foreach ($users as $user) {
                    echo "<tr>";
                    echo "<td>{$user['id']}</td>";
                    echo "<td>{$user['name']}</td>";
                    echo "<td>{$user['address']}</td>";
                    echo "<td>{$user['city']}</td>";
                    echo "<td>{$user['gender']}</td>";
                    echo "<td>{$user['email']}</td>";
                    echo "<td>{$user['registered']}</td>";
                    echo "<td>{$user['last_login']}</td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
    <button id="downloadReport">Download Report as PDF</button>

    <script>
        $(document).ready(function() {
            // Initialize DataTable
            $('#userTable').DataTable();
        });

        // User Roles Distribution Chart
        new Chart(document.getElementById('userRolesChart'), {
            type: 'doughnut',
            data: {
                labels: ['Patients', 'Doctors', 'Admin'],
                datasets: [{
                    data: [20, 15, 5],
                    backgroundColor: ['#36a2eb', '#ff6384', '#ffcd56'],
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'top' } }
            }
        });

        // Monthly User Registrations Chart
        new Chart(document.getElementById('userRegistrationsChart'), {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
                datasets: [{
                    label: 'New Registrations',
                    data: [5, 10, 8, 15, 12, 20, 18],
                    fill: false,
                    borderColor: '#36a2eb',
                }]
            },
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });

        // Registrations by User Type Chart
        new Chart(document.getElementById('registrationsByUserTypeChart'), {
            type: 'bar',
            data: {
                labels: ['Patients', 'Doctors', 'Admin'],
                datasets: [{
                    label: 'Registrations',
                    data: [30, 10, 5],
                    backgroundColor: ['#ff6384', '#36a2eb', '#ffcd56'],
                }]
            },
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });

        // Monthly Appointments Chart
        new Chart(document.getElementById('appointmentsChart'), {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
                datasets: [{
                    label: 'Appointments',
                    data: [15, 25, 30, 20, 35, 40, 45],
                    backgroundColor: '#ffcd56',
                }]
            },
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });
        


        
    </script>
</body>
</html>
