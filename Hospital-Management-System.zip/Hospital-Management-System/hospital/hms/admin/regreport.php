<?php /* Configuration-only PHP file */ ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Operational Efficiency Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            line-height: 1.6;
        }
        h1, h2 {
            text-align: center;
            color: #2c3e50;
        }
        .section {
            border: 1px solid #3498db;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .chart-container {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .chart {
            width: 32%; /* Ensure each chart takes up a third of the row */
        }
        .notes {
            color: #555;
            font-style: italic;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

    <h1>Operational Efficiency Report</h1>
    <h2>Hospital: [Hospital Name]</h2>
    <h3>Reporting Period: [Start Date] - [End Date]</h3>

    <div class="section">
        <h2>Key Efficiency Indicators</h2>
        <div class="chart-container">
            <canvas id="waitTimeChart" class="chart"></canvas>
            <canvas id="staffResponseChart" class="chart"></canvas>
            <canvas id="bedOccupancyChart" class="chart"></canvas>
        </div>
    </div>

    <div class="section">
        <h2>Notes and Recommendations</h2>
        <p class="notes">This report highlights critical operational efficiency indicators for patient wait times, staff response, and bed occupancy. Recommendations focus on optimizing response times, reducing wait times, and improving bed utilization.</p>
    </div>

    <script>
        // Patient Wait Times Chart (Bar Chart)
        const waitTimeChart = new Chart(document.getElementById('waitTimeChart'), {
            type: 'bar',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May'],
                datasets: [{
                    label: 'Average Wait Time (minutes)',
                    data: [30, 28, 25, 32, 20],
                    backgroundColor: '#3498db'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true, title: { display: true, text: 'Minutes' } }
                },
                plugins: {
                    legend: { display: true, position: 'top' }
                }
            }
        });

        // Staff Response Times Chart (Line Chart)
        const staffResponseChart = new Chart(document.getElementById('staffResponseChart'), {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May'],
                datasets: [{
                    label: 'Response Time (minutes)',
                    data: [8, 9, 7, 6, 8],
                    backgroundColor: 'rgba(52, 152, 219, 0.2)',
                    borderColor: '#3498db',
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true, title: { display: true, text: 'Minutes' } }
                },
                plugins: {
                    legend: { display: true, position: 'top' }
                }
            }
        });

        // Bed Occupancy Rate Chart (Pie Chart)
        const bedOccupancyChart = new Chart(document.getElementById('bedOccupancyChart'), {
            type: 'pie',
            data: {
                labels: ['Occupied', 'Available'],
                datasets: [{
                    label: 'Bed Occupancy Rate',
                    data: [75, 25],
                    backgroundColor: ['#e74c3c', '#2ecc71']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'right' }
                }
            }
        });
    </script>

</body>
</html>
