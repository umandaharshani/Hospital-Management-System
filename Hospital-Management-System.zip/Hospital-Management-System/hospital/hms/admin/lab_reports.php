<?php
// Database connection (update with your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_report'])) {
    $patient_name = $_POST['patient_name'];
    $report_date = $_POST['report_date'];
    $invoice_number = $_POST['invoice_number'];
    $file = $_FILES['lab_report'];

    // Upload file handling
    $fileName = $file['name'];
    $fileTmpName = $file['tmp_name'];
    $fileError = $file['error'];

    if ($fileError === 0) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true); // Create uploads directory if it doesn't exist
        }

        $filePath = $uploadDir . basename($fileName);
        if (move_uploaded_file($fileTmpName, $filePath)) {
            // Insert into the database
            $stmt = $conn->prepare("INSERT INTO lab_reports (patient_name, report_date, invoice_number, file_path) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $patient_name, $report_date, $invoice_number, $filePath);
            $stmt->execute();
            $stmt->close();
        }
    }
}

// Handle search by invoice number
$searchInvoiceNumber = "";
if (isset($_GET['search'])) {
    $searchInvoiceNumber = $_GET['invoice_number'];
}

// Fetch lab reports from the database
$query = "SELECT * FROM lab_reports";
if ($searchInvoiceNumber) {
    $query .= " WHERE invoice_number = '" . $conn->real_escape_string($searchInvoiceNumber) . "'";
}
$result = $conn->query($query);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Reports - HMS Health Care</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Upload Lab Report</h2>
        <form action="" method="post" enctype="multipart/form-data" class="mb-4">
            <div class="form-group">
                <label for="patient_name">Patient Name</label>
                <input type="text" class="form-control" id="patient_name" name="patient_name" required>
            </div>
            <div class="form-group">
                <label for="report_date">Report Date</label>
                <input type="date" class="form-control" id="report_date" name="report_date" required>
            </div>
            <div class="form-group">
                <label for="invoice_number">Invoice Number</label>
                <input type="text" class="form-control" id="invoice_number" name="invoice_number" required>
            </div>
            <div class="form-group">
                <label for="lab_report">Upload Report (PDF or Image)</label>
                <input type="file" class="form-control-file" id="lab_report" name="lab_report" accept=".pdf,.jpg,.jpeg,.png" required>
            </div>
            <button type="submit" class="btn btn-primary" name="upload_report">Upload Report</button>
        </form>

        <h2 class="text-center">Search Lab Reports</h2>
        <form method="get" class="mb-4">
            <div class="form-group">
                <label for="invoice_number">Invoice Number</label>
                <input type="text" class="form-control" id="invoice_number" name="invoice_number" value="<?php echo htmlspecialchars($searchInvoiceNumber); ?>">
            </div>
            <button type="submit" class="btn btn-secondary" name="search">Search</button>
        </form>

        <h2 class="text-center">Uploaded Lab Reports</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Patient Name</th>
                    <th>Report Date</th>
                    <th>Invoice Number</th>
                    <th>File</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['patient_name']; ?></td>
                            <td><?php echo $row['report_date']; ?></td>
                            <td><?php echo $row['invoice_number']; ?></td>
                            <td><a href="<?php echo $row['file_path']; ?>" target="_blank">View Report</a></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No lab reports found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
