<?php
// Connect to the database
include('include/config.php'); // Ensure your database connection details in this file are correct

// Handle form submission to insert new staff details
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $position = $_POST['position'];
    $department = $_POST['department'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $hire_date = $_POST['hire_date'];

    // Using prepared statements for security
    $stmt = $con->prepare("INSERT INTO staff (name, position, department, contact_number, email, hire_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $position, $department, $contact_number, $email, $hire_date);

    // Execute the statement and update the table
    $stmt->execute();
    $stmt->close();
}

// Query to fetch all staff details
$query = mysqli_query($con, "SELECT * FROM staff");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Staff Details</title>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }
        .form-section {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
        }
        .table-section {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 5px;
        }
        h2 {
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">Hospital Staff Details</h2>

        <!-- Form to add new staff member -->
        <div class="form-section">
            <h4>Add New Staff Member</h4>
            <form method="post" action="">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="position">Position</label>
                    <input type="text" class="form-control" id="position" name="position" required>
                </div>
                <div class="form-group">
                    <label for="department">Department</label>
                    <input type="text" class="form-control" id="department" name="department" required>
                </div>
                <div class="form-group">
                    <label for="contact_number">Contact Number</label>
                    <input type="text" class="form-control" id="contact_number" name="contact_number" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="hire_date">Hire Date</label>
                    <input type="date" class="form-control" id="hire_date" name="hire_date" required>
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Add Staff Member</button>
            </form>
        </div>

        <!-- Table to display staff details -->
        <div class="table-section">
            <table class="table table-bordered table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Department</th>
                        <th>Contact Number</th>
                        <th>Email</th>
                        <th>Hire Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                        <tr>
                            <td><?php echo htmlentities($row['id']); ?></td>
                            <td><?php echo htmlentities($row['name']); ?></td>
                            <td><?php echo htmlentities($row['position']); ?></td>
                            <td><?php echo htmlentities($row['department']); ?></td>
                            <td><?php echo htmlentities($row['contact_number']); ?></td>
                            <td><?php echo htmlentities($row['email']); ?></td>
                            <td><?php echo htmlentities($row['hire_date']); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
