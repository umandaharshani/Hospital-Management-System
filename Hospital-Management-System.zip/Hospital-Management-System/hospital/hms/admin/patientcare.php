<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Care Quality Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50;
        }
        .charts-container {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
        }
        .chart-container {
            width: 32%;
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin: 10px;
        }
        .chart-container h3 {
            text-align: center;
            color: #2c3e50;
        }
        .report-container {
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin: 20px 0;
        }
        .report-container h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        .report-section {
            margin: 20px 0;
            border-bottom: 2px solid #ececec;
            padding-bottom: 10px;
        }
        .report-section:last-child {
            border: none;
        }
        .report-section h4 {
            color: #34495e;
            margin-bottom: 10px;
        }
        .report-section p, .report-section ul {
            margin: 5px 0;
        }
        .report-section ul {
            margin-left: 20px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
            color: #7f8c8d;
        }
    </style>
</head>
<body>

    <h1>Patient Care Quality Report</h1>

    <div class="charts-container">
        <div class="chart-container">
            <h3>Patient Safety Events</h3>
            <canvas id="patientSafetyEventsChart"></canvas>
        </div>
        <div class="chart-container">
            <h3>Medication Errors</h3>
            <canvas id="medicationErrorsChart"></canvas>
        </div>
        <div class="chart-container">
            <h3>Clinical Outcomes</h3>
            <canvas id="clinicalOutcomesChart"></canvas>
        </div>
    </div>

    <div class="report-container">
        <h2>Detailed Report</h2>
        
        <div class="report-section">
            <h4>Clinical Outcomes</h4>
            <p><strong>Surgical Success Rates:</strong> 95%</p>
            <p><strong>Average Length of Stay:</strong> 4 days</p>
            <p><strong>Discharge Planning Compliance:</strong> 90%</p>
        </div>

        <div class="report-section">
            <h4>Medication Errors</h4>
            <p>Total Medication Errors Reported: 15</p>
            <p>Error Types:</p>
            <ul>
                <li>Dosage Errors: 8</li>
                <li>Administration Errors: 5</li>
            </ul>
            <p>Action Taken:Implemented a new electronic medication administration system to enhance accuracy and tracking.</p>
        </div>

        <div class="report-section">
            <h4>Patient Satisfaction Scores</h4>
            <p>Overall Satisfaction Score: 87%</p>
            <p>Patient Feedback Summary: Patients expressed high satisfaction with nursing staff but highlighted longer wait times in the emergency department as a concern. Future improvements in staffing and process efficiency are recommended to address this issue.</p>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
    </div>

    <script>
        // Patient Safety Events Chart
        const ctx1 = document.getElementById('patientSafetyEventsChart').getContext('2d');
        const patientSafetyEventsChart = new Chart(ctx1, {
            type: 'pie',
            data: {
                labels: ['Falls', 'Pressure Ulcers', 'Other'],
                datasets: [{
                    label: 'Patient Safety Events',
                    data: [5, 3, 2],
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Patient Safety Events Distribution'
                    }
                }
            }
        });

        // Medication Errors Chart
        const ctx2 = document.getElementById('medicationErrorsChart').getContext('2d');
        const medicationErrorsChart = new Chart(ctx2, {
            type: 'bar',
            data: {
                labels: ['Dosage Errors', 'Administration Errors', 'Documentation Errors'],
                datasets: [{
                    label: 'Medication Errors',
                    data: [8, 5, 2],
                    backgroundColor: ['#36A2EB', '#FFCE56', '#FF6384'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Medication Errors'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Errors'
                        }
                    }
                }
            }
        });

        // Clinical Outcomes Chart
        const ctx3 = document.getElementById('clinicalOutcomesChart').getContext('2d');
        const clinicalOutcomesChart = new Chart(ctx3, {
            type: 'bar',
            data: {
                labels: ['Surgical Success Rate', '30-Day Readmission Rate', 'Overall Satisfaction'],
                datasets: [{
                    label: 'Clinical Outcomes',
                    data: [95, 12, 87],
                    backgroundColor: ['#36A2EB', '#FFCE56', '#FF6384'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Clinical Outcomes'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Percentage'
                        }
                    }
                }
            }
        });
    </script>

</body>
</html>
