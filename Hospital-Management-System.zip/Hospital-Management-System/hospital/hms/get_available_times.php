<?php
include('include/config.php');

if (isset($_POST['doctor']) && isset($_POST['date'])) {
    $doctorId = $_POST['doctor'];
    $date = $_POST['date'];

    $query = mysqli_query($con, "SELECT appointmentTime FROM appointment WHERE doctorId='$doctorId' AND appointmentDate='$date'");
    $bookedTimes = array();
    while ($row = mysqli_fetch_array($query)) {
        $bookedTimes[] = $row['appointmentTime'];
    }

    $allTimes = ["01:45 PM", "02:00 PM", "02:15 PM", "02:30 PM", "02:45 PM", "03:00 PM", "03:15 PM"]; // Example time slots
    $availableTimes = array_diff($allTimes, $bookedTimes);

    foreach ($availableTimes as $time) {
        echo "<option value=\"$time\">$time</option>";
    }
}
?>
